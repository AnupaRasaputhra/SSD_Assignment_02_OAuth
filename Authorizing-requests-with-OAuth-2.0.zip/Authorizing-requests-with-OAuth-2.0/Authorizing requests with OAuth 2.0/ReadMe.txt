*-----------------------------------------*
*---Request Authorization with OAuth 2.0--*
*-----------------------------------------*

This project is about how authorization can be done by using OAuth 2.0 to access
Facebook API.

Web Application Programming Language: ASP.Net C#

Steps to run
____________

* Launch the developed project using Visual Studio 2015 or above version.
* Start the program after selecting Greenland.aspx web form.
* The web application can access via localhost.